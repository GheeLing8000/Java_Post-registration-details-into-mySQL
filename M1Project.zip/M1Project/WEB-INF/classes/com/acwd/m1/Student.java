package com.acwd.m1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * This is a public class containing studentId,
 * firstName,lastName, gender, address,phone number
 * and course set as private parameters
 */


public class Student {
    private String studentId; //type String is declared for studentId
    private String firstName;//type String is declared for firstName
    private String lastName; //type String is declared for lastName
    private String gender;
    private String address;
    private String phone;
    private String course;


    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }


    public int insertData() throws SQLException, ClassNotFoundException {
        int rowsInserted = -1;
        /**
         * This is a method to establish connection to database,
         */




        Connection connection = this.getConnection();
        /**
         * This prepares the SQL statement
         */
        String sql = "INSERT INTO `studentmaster`" +
                "(`student_firstname`,\n" +
                "`student_lastname`,\n" +
                "`residential_address`,\n" +
                "`phone_number`,\n" +
                "`course_id`,\n" +
                "`gender`)\n" +
                "VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = connection.prepareStatement(sql);

        pst.setString(1, this.firstName);
        pst.setString(2, this.lastName);
        pst.setString(3, this.address);
        pst.setString(4, this.phone);
        pst.setString(5, this.course);
        pst.setString(6, this.gender);

        rowsInserted = pst.executeUpdate();
        /**
         * executes sql statement to return values of rows inserted
         */
        return rowsInserted;
    }

    private Connection getConnection() throws ClassNotFoundException, SQLException {
        /** Establish the connection to the database
         * return conn
         */
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/m1project",
                "root", "root");
        return  conn;
    }
    public boolean isFirstNameEqualsLastName() {
        /**
         * validate the firstName is not the same as lastName
         * return boolean
         */
        if (this.firstName == this.lastName) {
            return true;
        } else {
            return false;
        }
    }

        public boolean isFirstNameEqualsEmpty()
        {
            /**
             * validate the firstName contains some string or value
             * return boolean
             */
            if (this.firstName.isEmpty()) {
                return false;
            } else {
                return true;
            }
        }
    public boolean isPhoneNumberEqualsElevenInteger()
    {
        /**
         * validate the phone number is 11 digits and contains value
         * return boolean
         */
        if (this.phone.isEmpty() || this.phone.length()>11 ) {
            return false;
        } else {
            return true;
        }
    }

    //public void setPstatement(PreparedStatement pstatement) {
       // this.pstatement = pstatement;//
    //}//


}
