package com.acwd.m1;

import java.sql.SQLException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;

class StudentTest {
    Student student = new Student();

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        student.setFirstName("Jey");
        student.setLastName("Rash");
        student.setGender("Female");
        student.setAddress("44 Advoerss Singapore");
        student.setPhone("454554765");
        student.setCourse("1");
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void setLastName() {
        assertEquals("Rash", student.getLastName());
    }

    @org.junit.jupiter.api.Test
    void setFirstName() {
        assertEquals("Jey", student.getFirstName());
    }

    @Test

    void isFirstNameEqualsLastName(){

        assertFalse(student.isFirstNameEqualsLastName());
    }


    @org.junit.jupiter.api.Test
    void setGender() {
    }

    @org.junit.jupiter.api.Test
    void setAddress() {
 }

    @org.junit.jupiter.api.Test
    void setPhone() {
    }

    @org.junit.jupiter.api.Test
    void setCourse() {
    }

    @org.junit.jupiter.api.Test
    void insertData() {

        try {
            assertEquals(1, student.insertData());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}