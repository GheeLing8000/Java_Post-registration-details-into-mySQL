package com.acwd.m1;
/**
 * @author OhGheeLing
 * version 1.0
 * @since 2019-04-26
 *
 */

import java.sql.SQLException;
/**
 * The main class will set the values from
 * student classes after calling the
 * student class.
 * It uses try catch method to ensure
 * firstName is filled up and phone
 * number is filled up and not more than 11 digits
 */

public class Main {

    public static void main(String[] args) {

        /**
         * calls student class and modifies original values of
         * FirstName,LastName,Gender, Address, Phone,Course
         */
        Student student = new Student();

        student.setFirstName("Jey");
        student.setLastName("Rash");
        student.setGender("Female");
        student.setAddress("44 Advoerss Singapore");
        student.setPhone("454554765");
        student.setCourse("1");

        try {
            if (student.isFirstNameEqualsEmpty()){
                System.out.println("First Name shouldn't be empty!");

            }
            if (student.isPhoneNumberEqualsElevenInteger()){
                System.out.println("Phone Number shouldn't be less than 11 or empty!");

            }
            student.insertData();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
